import { Observer } from './types';
export declare const empty: Observer<any>;
