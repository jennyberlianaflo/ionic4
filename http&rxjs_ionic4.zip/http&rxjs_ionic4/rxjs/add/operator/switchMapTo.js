"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("rxjs-compat/add/operator/switchMapTo");
//# sourceMappingURL=switchMapTo.js.map