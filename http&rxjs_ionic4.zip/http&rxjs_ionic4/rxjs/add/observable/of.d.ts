import 'rxjs-compat/add/observable/of';
