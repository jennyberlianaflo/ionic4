import 'rxjs-compat/add/observable/merge';
